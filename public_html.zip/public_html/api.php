


<?php

ini_set("allow_url_fopen", 1);


$url = "report.json"; // path to your JSON file

$data = file_get_contents($url); // put the contents of the file into a variable
$feed= json_decode($data); // decode the JSON feed

$foods = $feed->foods[0]->{'food'}->{'desc'}->{'name'};


print($foods);



//$parsed_json->{'forecastday'}->{'period[0]'}->{'fcttext'};








?>

