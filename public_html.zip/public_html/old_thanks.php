<?php

  $name  = $_POST['name'];
  $email = $_POST['email'];
  $text  = $_POST['textArea'];
  $ip    = $_SERVER['REMOTE_ADDR'];
  
  $msg = $name . "\n"  . $email . "\n\n\n" . $text  ;

// send email
mail("ryan@ryanleissner.com","Web Form Message", $msg, $ip);

$newURL = 'http://www.ryanleissner.com';
header( "refresh:5;url=https://www.ryanleissner.com" );

echo "Thanks $name! You will be returned to RyanLeissner.com shortly";



?>