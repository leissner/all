<!doctype html>
<html>
  <head><title></title></head>
  <body>
  
  <?php
  
    include('mySQL1.php');
    
    if ($result = $mysqli->query("SELECT * FROM SteakPrice ORDER BY id")) {
      
      if ($result->num_rows > 0) {
        
        echo "<table border='1' cellpadding='10' >";
        echo "<tr><th>ID</th><th>Store</th><th>Cut</th><th>Price</th><th>EDIT</th><th>DELETE</th>";
        
          while ($row = $result->fetch_object()) {
            echo '<tr>';
            echo '<td>' . $row->id . '</td>';
            echo '<td>' . $row->store . '</td>';
            echo '<td>' . $row->cut . '</td>';
            echo '<td>$' . $row->price . '</td>';
            echo "<td><a href='records.php?id=" . $row->id ."'> EDIT </a></td>";
            echo "<td><a href='delete.php?id=" . $row->id ."'> DELETE </a></td>";

            
          }
        
        echo "</table>";
        
      }
      
      else {
        echo '0 results';
      
        
      }
    }
    
    else {
      echo "error: " . $mysqli->error;
    }
    
    $mysqli->close();
  
  ?>
  
  <a href='records.php'>add new record</a>
    
    
  </body>
</html>
