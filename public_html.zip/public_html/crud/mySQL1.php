<?php
      $serverame = 'localhost';
      $username = 'u288618782_ryan';
      $password = 'yjt0ioV4ZQcnTtGujS';
      $dbname = 'u288618782_crud';
      
      $mysqli = new mysqli($serverame, $username,$password,$dbname );
      
      mysqli_report(MYSQLI_REPORT_ERROR);
      
      ?>
      
