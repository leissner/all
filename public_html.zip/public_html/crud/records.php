
<?php


       function renderForm($name = '', $error = '', $id = ''){
 
 ?>
 
 <!DOCTYPE html>
 <html>
   <head>
   <title>
   <?php
      
      if ($id !='') {
        echo "Edit Record";
      }
      else {
        echo "New Record";
      }
   
   ?>
   </title>
   
   </head>
   <body>
     
    <h1>
      <?php
        
        if ($id !='') {
          echo "Edit Record";
        }
        else {
          echo "New Record";
        }
     
     ?>
   </h1>
   
    <?php
      if ($error !='') {
        echo $error;
      }
    ?>
     
   </body>
   
 </html>
  
  <?php
  
      if (isset($_GET['id'])) {
        echo 'id is set'; } else {
        echo 'id is not set';
      }}

  ?>
