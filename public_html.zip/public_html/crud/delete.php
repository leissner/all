<?php

include('mySQL1.php');

  if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    
      $id = $_GET['id'];
  
          if ($stmt = $mysqli->prepare("DELETE FROM SteakPrice WHERE id = ? LIMIT 1")) {
            
              if ($stmt = $mysqli->prepare("DELETE FROM SteakPrice WHERE id = ? LIMIT 1")) {
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                    $stmt->close();
                    
                    header('Location: viewRecords.php');

                  }
    
  }
 
  
  else {

  header('Location: mySQL1.php');
  
  }}

?>